export const COMMON_DATABASE = 'common';
export const LOGGING_DATABASE = 'logging';
export const GENE_DATABASE = 'gene';
export const AGENDA_DATABASE = 'agenda';
export const APPLICATION_NAME_FOR_MONGO = 'univar-backend';
export const MONGOOSE_AUTH_SOURCE = 'admin';
export const MONGOOSE_AUTH_MECHANISM = 'DEFAULT';
