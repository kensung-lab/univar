export const PROMISES_REJECTED = 'rejected';
