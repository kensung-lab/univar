export const BRAND_UNIVAR = 'univar';
export const BRAND_UNIVAR_DEFAULT_ACCESS_GROUP = 'default';
export const BRAND_UNIVAR_UPLOAD_FILE_SIZE_LIMIT = 1024 * 1024 * 1024; // 1GB
export const BRAND_SKIP_EXOMISER = 'skip-exomiser';
