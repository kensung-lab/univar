export const NO_SUCH_GROUP = 'nosuchteam';
export const B_TEAM = 'Bioinformatics Branch';
export const S_TEAM = 'HKGI Scientific';
export const DB_B_TEAM = 'bteam';
export const DB_S_TEAM = 'steam';
export const SUPER_GROUP = B_TEAM;
