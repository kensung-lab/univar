export const WAIT_STATUS = 'wait';
