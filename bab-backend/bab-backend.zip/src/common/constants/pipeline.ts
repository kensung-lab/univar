export const HPO_PIPELINE_DEFAULT_NAME = 'Init Run';
