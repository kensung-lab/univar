export enum RoleMatchingMode {
  /**
   * Match all roles
   */
  ALL = 'all',
  /**
   * Match any roles
   */
  ANY = 'any',
}
