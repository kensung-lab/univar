export const SHOW_VERSION = ['Panel AU', 'Panel UK'];
