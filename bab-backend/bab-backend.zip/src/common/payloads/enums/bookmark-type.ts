export enum BookmarkType {
  bookmark = 'bookmark',
  filter = 'filter',
}
