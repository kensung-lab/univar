export class DatabaseFilter {
  samples?: string[];
  access_group?: string[] | any;
  database_name?: string;
  display_name?: number;
  brand?: string;
  is_ready?: boolean;
}
