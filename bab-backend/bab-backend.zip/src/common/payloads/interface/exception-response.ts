export interface ExceptionResponse {
  statusCode?: number;
  message: string;
  error: string;
}
