export class SVFileInfo {
  filename: string;
  caller: string;
}
