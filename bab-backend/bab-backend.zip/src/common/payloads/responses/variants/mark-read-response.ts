export class MarkReadResponse {
  success_list: string[];
}
