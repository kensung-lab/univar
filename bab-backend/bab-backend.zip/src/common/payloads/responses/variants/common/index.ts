export * from './base-variant';
