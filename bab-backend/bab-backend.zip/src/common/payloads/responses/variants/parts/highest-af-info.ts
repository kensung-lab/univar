export class HighestAFInfo {
  source?: string;
}
