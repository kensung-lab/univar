import { Variant } from '.';
import { Paging } from '../../common';

export class VariantData {
  page_info: Paging;
  result: Variant[];
}
