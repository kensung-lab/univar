import { Paging, Sample } from '../..';

export class SampleData {
  page_info: Paging;
  result: Sample[];
}
