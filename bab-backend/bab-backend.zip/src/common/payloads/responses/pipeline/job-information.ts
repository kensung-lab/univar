export class JobInformation {
  job_id: string;

  constructor(jobId: string) {
    this.job_id = jobId;
  }
}
