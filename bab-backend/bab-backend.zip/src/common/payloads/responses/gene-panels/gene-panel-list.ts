import { GenePanel } from './gene-panel';

export class GenePanelList {
  genePanels: GenePanel[];

  lastModifyDate: Date;
}
