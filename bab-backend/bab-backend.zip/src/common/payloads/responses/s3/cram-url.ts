export class CramUrl {
  sample_id: string;

  cram_url: string;

  cram_index_url: string;

  constructor(sample_id: string) {
    this.sample_id = sample_id;
  }
}
