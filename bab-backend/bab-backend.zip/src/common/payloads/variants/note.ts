export class Note {
  user: string;
  note: string;
}
