import { RoleAccess } from './role-access';

export class ResourceAccess {
  account: RoleAccess;
}
