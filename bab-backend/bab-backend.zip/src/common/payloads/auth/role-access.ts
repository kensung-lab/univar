export class RoleAccess {
  roles: string[];
}
