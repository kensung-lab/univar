export * from './role-decorator-options.interface';
