export * from './gene.service';
