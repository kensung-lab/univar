export * from './variant.controller';
export * from './sample.controller';
export * from './gene-db.controller';
